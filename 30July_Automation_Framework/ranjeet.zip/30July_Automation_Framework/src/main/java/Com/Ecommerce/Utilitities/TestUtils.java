package Com.Ecommerce.Utilitities;

public class TestUtils {

	
	public static int IMPLICIT_WAIT =20;
	
	public static int PAGE_LOAD_TIMEOUT =20;

}
